class Materia {
    constructor(id, carreraId, docenteId, nombre, codigo, anho) {
        this.mate_id = id;
        this.carre_id = carreraId;
        this.doce_id = docenteId;
        this.mate_name = nombre;
        this.mate_codi = codigo;
        this.mate_anho = anho;
    }
}
