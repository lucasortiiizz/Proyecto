class Docente {
    constructor(id, apellido, nombre, mail, cumple, cel) {
        this.doce_id = id;
        this.doce_apellido = apellido;
        this.doce_nombre = nombre;
        this.doce_mail = mail;
        this.doce_cumple = cumple;
        this.doce_cel = cel;
    }
}
